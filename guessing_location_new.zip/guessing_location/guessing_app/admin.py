from django.contrib import admin
from .models import HomePageImage,Comments
# Register your models here.
admin.site.register(HomePageImage)
admin.site.register(Comments)
# Register your models here.
